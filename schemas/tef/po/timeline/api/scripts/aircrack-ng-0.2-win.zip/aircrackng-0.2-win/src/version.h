#define _MAJ 0
#define _MIN 2
#define PROG_NAME "Aircrack-ng"
#define BETA 0
#define BETA_NO 0
#define WEBSITE "http://www.aircrack-ng.org"
